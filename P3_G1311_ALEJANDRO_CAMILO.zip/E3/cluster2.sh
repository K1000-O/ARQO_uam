#!/bin/bash
#
#$ -S /bin/bash
#$ -cwd
#$ -o salida.out
#$ -j y
# Anadir valgrind y gnuplot al path
export PATH=$PATH:/share/apps/tools/valgrind/bin:/share/apps/tools/gnuplot/bin
# Indicar ruta librerías valgrind
export VALGRIND_LIB=/share/apps/tools/valgrind/lib/valgrind

# inicializar variables
Ninicio=$((256+256*7)) # Somos el grupo 10, por lo tanto P = 10%7 + 4 = 3 + 4 = 7.
Npaso=32 #Incremento de salto de 64 unidades.
Nfinal=$((256+256*8))
TamLL=8388608
Tinicial=1024
Tfinal=8192

for ((cache = Tinicial; cache <= Tfinal; cache *= 2)); do
	fDAT=cache_$cache.dat
	# borrar el fichero DAT
	rm -f ./ficheros_dat/$fDAT

	# generar el fichero DAT vacío
	touch $fDAT
	
	echo " "
	echo "	####### EJECUTANDO SLOW and FAST PARA LA CACHE $cache #######"
	# bucle para N desde P hasta Q 
	#for N in $(seq $Ninicio $Npaso $Nfinal);
	for ((N = Ninicio ; N <= Nfinal ; N += Npaso)); do	
		# ejecutar los programas slow y fast consecutivamente con tamaño de matriz N
		# para cada uno, filtrar la línea que contiene el tiempo y seleccionar la
		# tercera columna (el valor del tiempo). Dejar los valores en variables
		# para poder imprimirlos en la misma línea del fichero de datos
		echo "N: $N / $Nfinal..."
		
		valgrind --tool=cachegrind --I1=$cache,1,64 --D1=$cache,1,64 --LL=$TamLL,1,64 --cachegrind-out-file=ls_out.dat -q ./multiplicacion $N
		tail -n 1 ls_out.dat > aux.dat
		slowTime1=$(awk '{print $6}' aux.dat)
		slowTime2=$(awk '{print $9}' aux.dat)
		valgrind --tool=cachegrind --I1=$cache,1,64 --D1=$cache,1,64 --LL=$TamLL,1,64 --cachegrind-out-file=ls_out.dat -q ./multiplicacion $N+1
		
		valgrind --tool=cachegrind --I1=$cache,1,64 --D1=$cache,1,64 --LL=$TamLL,1,64 --cachegrind-out-file=ls_out.dat -q ./multiplicacionTraspuesta $N
		tail -n 1 ls_out.dat > aux.dat
		fastTime1=$(awk '{print $6}' aux.dat)
		fastTime2=$(awk '{print $9}' aux.dat)
		valgrind --tool=cachegrind --I1=$cache,1,64 --D1=$cache,1,64 --LL=$TamLL,1,64 --cachegrind-out-file=ls_out.dat -q ./multiplicacionTraspuesta $N+1
		

		echo "$N $slowTime1 $slowTime2 $fastTime1 $fastTime2" >> $fDAT
	done
done

rm -rf aux.dat
rm -rf ls_out.dat
rm -rf ls_out.dat

echo "Generating reading plot..."
# llamar a gnuplot para generar el gráfico y pasarle directamente por la entrada
# estándar el script que está entre "<< END_GNUPLOT" y "END_GNUPLOT"
gnuplot << END_GNUPLOT
set title "Fallos de lectura"
set ylabel "Fallos de cache"
set xlabel "Matrix Size"
set key right bottom
set grid
set term png
set output "cache_lectura.png"
plot "cache_1024.dat" using 1:2 with lines lw 2 title "slow 1024", \
	 "cache_1024.dat" using 1:4 with lines lw 2 title "fast 1024", \
	 "cache_2048.dat" using 1:2 with lines lw 2 title "slow 2048", \
	 "cache_2048.dat" using 1:4 with lines lw 2 title "fast 2048", \
	 "cache_4096.dat" using 1:2 with lines lw 2 title "slow 4096", \
	 "cache_4096.dat" using 1:4 with lines lw 2 title "fast 4096", \
	 "cache_8192.dat" using 1:2 with lines lw 2 title "slow 8192", \
	 "cache_8192.dat" using 1:4 with lines lw 2 title "fast 8192"
replot
quit
END_GNUPLOT

echo "Generating writing plot..."
# llamar a gnuplot para generar el gráfico y pasarle directamente por la entrada
# estándar el script que está entre "<< END_GNUPLOT" y "END_GNUPLOT"
gnuplot << END_GNUPLOT
set title "Fallos de escritura"
set ylabel "Fallos de cache"
set xlabel "Matrix Size"
set key right bottom
set grid
set term png
set output "cache_escritura.png"
plot "cache_1024.dat" using 1:3 with lines lw 2 title "slow 1024", \
	 "cache_1024.dat" using 1:5 with lines lw 2 title "fast 1024", \
	 "cache_2048.dat" using 1:3 with lines lw 2 title "slow 2048", \
	 "cache_2048.dat" using 1:5 with lines lw 2 title "fast 2048", \
	 "cache_4096.dat" using 1:3 with lines lw 2 title "slow 4096", \
	 "cache_4096.dat" using 1:5 with lines lw 2 title "fast 4096", \
	 "cache_8192.dat" using 1:3 with lines lw 2 title "slow 8192", \
	 "cache_8192.dat" using 1:5 with lines lw 2 title "fast 8192"
replot
quit
END_GNUPLOT

mv *.dat ./ficheros_dat
mv *.png ./imagenes_png