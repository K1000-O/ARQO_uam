#!/bin/bash
#
#$ -S /bin/bash
#$ -cwd
#$ -o salida1.out
#$ -j y
# Anadir valgrind y gnuplot al path
export PATH=$PATH:/share/apps/tools/valgrind/bin:/share/apps/tools/gnuplot/bin
# Indicar ruta librerías valgrind
export VALGRIND_LIB=/share/apps/tools/valgrind/lib/valgrind

# inicializar variables
Ninicio=$((256+256*3))
Npaso=32 #Incremento de salto de 32 unidades.
Nfinal=$((256+256*4))
fDAT=multiplicacion_time.dat
fPNG=multiplicacion_time.png

# borrar el fichero DAT y el fichero PNG
rm -f $fDAT fPNG

# generar el fichero DAT vacío
touch $fDAT

echo "Running slow and fast..."
# bucle para N desde P hasta Q 
#for N in $(seq $Ninicio $Npaso $Nfinal);
for ((N = Ninicio ; N <= Nfinal ; N += Npaso)); do	
	sumaSlowTime=0
	sumaFastTime=0
	# ejecutar los programas slow y fast consecutivamente con tamaño de matriz N
	# para cada uno, filtrar la línea que contiene el tiempo y seleccionar la
	# tercera columna (el valor del tiempo). Dejar los valores en variables
	# para poder imprimirlos en la misma línea del fichero de datos
	for ((i = 1; i <= 15; i++)); do
		echo "N: $N / $Nfinal... -- Nº $i"
		slowTime=$(./multiplicacion $N | grep 'Tiempo' | awk '{print $4}')
		slowTimeX=$(./multiplicacion $N+1 | grep 'Tiempo' | awk '{print $4}')
		fastTime=$(./multiplicacionTraspuesta $N | grep 'Tiempo' | awk '{print $4}')
		fastTimeX=$(./multiplicacionTraspuesta $N+1 | grep 'Tiempo' | awk '{print $4}')

		sumaSlowTime=$(echo "scale=10; $sumaSlowTime+$slowTime" | bc)
		sumaFastTime=$(echo "scale=10; $sumaFastTime+$fastTime" | bc)
		
	done
	
	mediaSumaSlowTime=$(echo "scale=10; ($sumaSlowTime/15)" | bc)
	mediaSumaFastTime=$(echo "scale=10; ($sumaFastTime/15)" | bc)
	
	echo "$N	$mediaSumaSlowTime	$mediaSumaFastTime" >> $fDAT
done

echo "Generating plot..."
# llamar a gnuplot para generar el gráfico y pasarle directamente por la entrada
# estándar el script que está entre "<< END_GNUPLOT" y "END_GNUPLOT"
gnuplot << END_GNUPLOT
set title "Slow-Fast Execution Time"
set ylabel "Execution time (s)"
set xlabel "Matrix Size"
set key right bottom
set grid
set term png
set output "$fPNG"
plot "$fDAT" using 1:2 with lines lw 2 title "slow", \
     "$fDAT" using 1:3 with lines lw 2 title "fast"
replot
quit
END_GNUPLOT
