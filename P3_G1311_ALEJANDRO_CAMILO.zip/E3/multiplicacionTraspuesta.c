#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "arqo3.h"

/* Metodo main que se encargara de multiplicar dos matrices cuadradas y calcular el tiempo que tarda en realizar la multiplicacion de las mismas. */
int main(int args, char* argv[]) {
	int i = 0, j = 0, k = 0, tam = 0;
	int sum = 0;
	struct timeval inicio, final;
	
	if (args != 2) {
		fprintf(stderr, "ERROR EN LOS PARAMETROS DE ENTRADA: \n");
		fprintf(stderr, "Sintaxis: %s < TAM de la matriz >", argv[0]);
		return 1;
	} else {
		if (atoi(argv[1]) <= 0) {
			fprintf(stderr, "Tam de la matriz demasiado pequeño.\n");
			return 1;
		} else {
			tam = atoi(argv[1]);
		}
	}
	
	/* Creamos la matriz a multiplicar y la vacía a la que se introducira el resultado. */
	double** matrizIni = generateMatrix(tam);
	double** matrizTraspuesta = generateEmptyMatrix(tam);
	double** matrizFinal = generateEmptyMatrix(tam);
	
	gettimeofday(&inicio, NULL);
	/* Realizamos la matriz traspuesta. */
	for (i = 0; i < tam; i++) {
		for (j = 0; j < tam; j++) {
			matrizTraspuesta[i][j] = matrizIni[j][i];
		}
	}
	
	/* Calculamos la multiplicacion */
	for (i = 0; i < tam; i++) {
		for (j = 0; j < tam; j++) {
			sum = 0;
			for (k = 0; k < tam; k++) {
				sum += matrizIni[i][k] * matrizTraspuesta[j][k]; 
			}
			
			matrizFinal[i][j] = sum;
		}
	}
	gettimeofday(&final, NULL);
	
	printf ("Tiempo de ejecucion: %f\n", ((final.tv_sec*1000000+final.tv_usec)-(inicio.tv_sec*1000000+inicio.tv_usec))*1.0/1000000.0);
	
	freeMatrix(matrizFinal);
	freeMatrix(matrizTraspuesta);
	freeMatrix(matrizIni);
	
	return 0;
}