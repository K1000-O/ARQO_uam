#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "arqo3.h"

/* Metodo main que se encargara de multiplicar dos matrices cuadradas y calcular el tiempo que tarda en realizar la multiplicacion de las mismas. */
int main(int args, char* argv[]) {
	int i = 0, j = 0, k = 0, tam = 0;
	int sum = 0;
	struct timeval inicio, final;
	
	if (args != 2) {
		fprintf(stderr, "ERROR EN LOS PARAMETROS DE ENTRADA: \n");
		fprintf(stderr, "Sintaxis: %s < TAM de la matriz >", argv[0]);
		return 1;
	} else {
		if (atoi(argv[1]) <= 0) {
			fprintf(stderr, "Tam de la matriz demasiado pequeño.\n");
			return 1;
		} else {
			tam = atoi(argv[1]);
		}
	}
	
	/* Creamos la matriz a multiplicar y la vacía a la que se introducira el resultado. */
	double** matrizIni1 = generateMatrix(tam);
	double** matrizIni2 = generateMatrix(tam);
	double** matrizFinal = generateEmptyMatrix(tam);
	
	gettimeofday(&inicio, NULL);
	for (i = 0; i < tam; i++) {
		for (j = 0; j < tam; j++) {
			sum = 0;
			for (k = 0; k < tam; k++) {
				sum += matrizIni1[i][k] * matrizIni2[k][j];
			}
			
			matrizFinal[i][j] = sum;
		}
	}
	gettimeofday(&final, NULL);
	
	printf ("Tiempo de ejecucion: %f\n", ((final.tv_sec*1000000+final.tv_usec)-(inicio.tv_sec*1000000+inicio.tv_usec))*1.0/1000000.0);
	
	freeMatrix(matrizFinal);
	freeMatrix(matrizIni1);
	freeMatrix(matrizIni2);
	
	return 0;
}